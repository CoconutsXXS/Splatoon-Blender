bl_info = {
    "name": "Splatoon Model Importer",
    "author": "Coconuts XXS",
    "version": (0, 3),
    "blender": (4, 0, 0),
    "location": "File > Import > Splatoon Model",
    "description": "Recreate a splatoon model from the .dae or .fbx file and the textures",
    "warning": "",
    "doc_url": "",
    "category": "Import",
}

import bpy
import os
from pathlib import Path
from pathlib import PurePath
from bpy.utils import resource_path
from mathutils import Vector

def path_iterator(folder_path):
    for fp in os.listdir(folder_path):
        if fp.endswith( tuple( bpy.path.extensions_image ) ):
            yield fp
        
def clean(obj):
    #bpy.ops.object.select_all(action='DESELECT')
    #obj.select_set(True)
    bpy.ops.object.mode_set(mode = 'EDIT') 
    mesh = obj.data
    connected_verts = []
    for edge in mesh.edges:
        connected_verts.append(edge.vertices[0])
        connected_verts.append(edge.vertices[1])
    connected_vert = set(connected_verts)
    unconnected_vert = set(range(len(mesh.vertices))) - connected_vert
    bpy.ops.mesh.select_all(action='DESELECT')
    for vert in connected_verts:
        bpy.ops.object.mode_set(mode='OBJECT')
        mesh.vertices[vert].select = True
    bpy.ops.object.editmode_toggle()
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
    bpy.ops.mesh.select_all(action='INVERT')
    bpy.ops.mesh.delete(type='VERT')

def import_item(self):
    path = str(os.path.split(self.filepath)[0]) + "/"
    file = str(os.path.split(self.filepath)[1])
    
    active_object = bpy.context.view_layer.objects.active
    
    bpy.ops.object.select_all(action='DESELECT')
    
    if file.endswith('.dae'):
        bpy.ops.wm.collada_import(filepath = path+file)
        
        for o in bpy.context.selected_objects:
            self.report({"INFO"}, str(o))
            if o.type == "LIGHT":
                bpy.ops.object.select_all(action='DESELECT')
                o.select_set(True)
                bpy.ops.object.delete()
            elif o.type == "ARMATURE":
                o.select_set(True)
                bpy.context.view_layer.objects.active = o
                
    elif file.endswith('.fbx'):
        bpy.ops.import_scene.fbx(filepath = path+file)
        
    nameToReset = len(self.name) == 0
    if nameToReset:
        self.name = PurePath(self.filepath).name.replace('.dae', '')[:60]
        
    blend_method = 'BLEND'
    if self.alpha_clip:
        blend_method = 'CLIP'
    
    obj = bpy.context.view_layer.objects.active
    obj.name = self.name
    obj.scale = (0.125,0.125,0.125)
    bpy.ops.object.scale_clear(clear_delta=False)

    edited_body = False
    edited_tank = False
    edited_roll = False
    mat_body = None
    mat_tank = None
    mat_roll = None
    
    model_armature = None
    
    #RIGING
    if obj.type == "ARMATURE":
        model_armature = obj
        root_bone = None
        obj.location = bpy.context.scene.cursor.location
        obj.rotation_euler = bpy.context.scene.cursor.rotation_euler
        
        if self.attach != "none":
            bpy.ops.object.posemode_toggle()
            bpy.ops.pose.select_all(action='SELECT')
            
            for bone in bpy.context.selected_pose_bones_from_active_object:
                if "root" in bone.name.lower():
                    constraint = bone.constraints.new(type='COPY_TRANSFORMS')
                    constraint.target = active_object
                    constraint.subtarget = self.attach
                    root_bone = bone
                    break
            bpy.ops.object.posemode_toggle()
        
        if self.armature_modif:
            bpy.ops.object.editmode_toggle()
            bpy.ops.armature.select_all(action='DESELECT')
            for bone in obj.data.edit_bones:
                self.report({'INFO'}, '- Bone: '+bone.name)
                
                if bone.name.startswith("Z_"):
                    self.report({'INFO'}, 'Removed bone: '+bone.name)
                    obj.data.edit_bones.remove(bone)
                    continue

                if len(bone.children) > 0 and bone != root_bone:
                    bpy.ops.armature.select_all(action='DESELECT')
    
                    if bone.children[0].head != None:
                        bone.tail = bone.children[0].head
                    
                    bone.select = True
                    bone.children[0].select = True
                    obj.data.edit_bones.active = bone
                    bpy.ops.armature.parent_set(type='CONNECTED')
                    
                    bpy.ops.armature.select_all(action='DESELECT')
                
                elif bone.parent != None and bone != root_bone and self.bone_orient:
                    bone.tail = bone.head + (bone.parent.tail - bone.parent.head)
                
                print(self, round(bone.tail[0]*100) == round(bone.head[0]*100) and round(bone.tail[1]*100) == round(bone.head[1]*100) and round(bone.tail[2]*100) == round(bone.head[2]*100))
                if round(bone.tail[0]*100) == round(bone.head[0]*100) and round(bone.tail[1]*100) == round(bone.head[1]*100) and round(bone.tail[2]*100) == round(bone.head[2]*100):
                    bone.head = bone.head + Vector((0, 0.01, 0))
            
            bpy.ops.armature.select_all(action='SELECT')
            bpy.ops.armature.symmetrize()
            bpy.context.object.data.display_type = 'WIRE'
            bpy.ops.object.editmode_toggle()
            
        if len(obj.data.bones) <= 1:
            empty = bpy.data.objects.new(self.name, None )
            bpy.context.scene.collection.objects.link(empty)
            empty.location = obj.location + obj.data.bones[0].head
            empty.rotation_euler = obj.rotation_euler
            empty.empty_display_size = 0.2

            
            for o in obj.children:
                o.parent = empty
                o.rotation_euler = (1.5708,0,0)
            
            bpy.data.objects.remove(obj, do_unlink=True)
            obj = model_armature = empty
            empty.name = self.name

        
    reconstitued_materials = []
        
    for child in obj.children:
        to_delete = False
        for x in range(10):
            if child.name.endswith(' (LOD: '+str(x)+')') or child.name.endswith('__LOD__'+str(x)+'_'):
                to_delete = True
                break
            
        if to_delete:
            bpy.ops.object.select_all(action='DESELECT')
            child.select_set(True)
            bpy.ops.object.delete()
            continue
        
        bpy.ops.object.select_all(action='DESELECT')
        child.select_set(True)
        bpy.context.view_layer.objects.active = child

        if child.type == "MESH":
            bpy.ops.object.editmode_toggle()
            
            if self.deep_optimisation:
                clean(child)
            if self.basic_optimisation:
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.tris_convert_to_quads(face_threshold=1, shape_threshold=1, uvs=True)
                bpy.ops.mesh.remove_doubles(threshold=0.001, use_unselected=True, use_sharp_edge_from_normals=True)
                bpy.ops.mesh.select_all(action='DESELECT')
            
            bpy.ops.object.editmode_toggle()
        
        # Old Deep Opti
        if False:
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.editmode_toggle()
            
            separate = bpy.context.selected_objects
            to_keep = []
            bpy.ops.object.select_all(action='DESELECT')
            for obj in separate:
                if len(obj.data.vertices) <= 1:
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(True)
                    bpy.ops.object.delete() 
                else:
                    to_keep.append(obj)
            bpy.ops.object.select_all(action='DESELECT')
            for obj in to_keep:
                obj.select_set(True)
                
            bpy.ops.object.join()
        
        # SHADING
        base_name = bpy.context.active_object.active_material.name
        to_edit=True
        
        edited_before = bpy.context.active_object.active_material in reconstitued_materials
        
        if bpy.context.active_object.active_material.name.startswith("Obj_"):
            base_name = base_name[4:]
        if bpy.context.active_object.active_material.name.startswith("obj_"):
            base_name = base_name[4:]
            
        for x in range(999):
            if base_name.endswith("."+("{:03d}".format(x))):
                base_name = base_name[:-4]
        
        if False:
            if bpy.context.active_object.active_material.name.startswith("M_Body"):
                if edited_body==True:
                    to_edit = False
                    bpy.context.active_object.active_material = mat_body
                else:
                    base_name = "m_body"
                    bpy.context.active_object.active_material.name = file[:-4] + " Body"
                    mat_body = bpy.context.active_object.active_material
                    edited_body=True
                    to_edit = True
                    
            if bpy.context.active_object.active_material.name.startswith("M_Tank") or bpy.context.active_object.active_material.name.endswith("Tank"):
                if edited_tank==True:
                    to_edit = False
                    bpy.context.active_object.active_material = mat_tank
                else:
                    base_name = "m_tank"
                    bpy.context.active_object.active_material.name = file[:-4] + " Tank"
                    mat_tank = bpy.context.active_object.active_material
                    edited_tank=True
                    to_edit = True
                    
            if bpy.context.active_object.active_material.name.startswith("M_Roll") or bpy.context.active_object.active_material.name.endswith("Roll"):
                if edited_roll==True:
                    to_edit = False
                    bpy.context.active_object.active_material = mat_roll
                else:
                    base_name = "m_roll"
                    bpy.context.active_object.active_material.name = file[:-4] + " Roll"
                    mat_roll = bpy.context.active_object.active_material
                    edited_roll=True
                    to_edit = True
                    
        if not edited_before:
            bpy.context.active_object.active_material.name = base_name + " - " + self.name
            #print(self, 'Material Name = '+bpy.context.active_object.active_material.name)
            if bpy.context.active_object.active_material.name.lower().startswith("m_"):
                bpy.context.active_object.active_material.name = bpy.context.active_object.active_material.name[2:]
        
            # NPC _ fix
            if base_name.lower().startswith('m_npc') and not base_name.lower().startswith('m_npc_'):
                base_name = base_name[:5] + '_' + base_name[5:]
            
        for mat in reconstitued_materials:
            #self.report({"INFO"}, mat.name+' = '+bpy.context.active_object.active_material.name[:-4])
            #self.report({"INFO"}, mat.name[:-4]+' = '+bpy.context.active_object.active_material.name)
            #self.report({"INFO"}, mat.name+' = '+bpy.context.active_object.active_material.name)
            if mat.name == bpy.context.active_object.active_material.name[:-4] or mat.name == bpy.context.active_object.active_material.name or mat.name[:-4] == bpy.context.active_object.active_material.name:
                to_edit = False
                bpy.context.active_object.active_material = mat

        
        if to_edit==True:
            
            is_eyelid = "eyelid" in base_name.lower() or "eye" in base_name.lower()
            #self.report({"INFO"}, 'Eyelids :'+str(is_eyelid))
            
            bpy.context.object.active_material.show_transparent_back = False
            tree = bpy.context.active_object.active_material.node_tree
            for node in tree.nodes:
                tree.nodes.remove(node)
        
            shader_output = tree.nodes.new(type="ShaderNodeOutputMaterial")
            shader_output.location = Vector((600.0, 0.0))
                
            group = bpy.data.node_groups.new(bpy.context.active_object.active_material.name, 'ShaderNodeTree')
            group_node = tree.nodes.new("ShaderNodeGroup")
            group_node.node_tree = group
            
            interface = group.interface
            
            input = group.nodes.new('NodeGroupInput')
            output = group.nodes.new('NodeGroupOutput')
            
            input.location = Vector((-2500, 0))
            output.location = Vector((2500, 0))
            
            nodes = group.nodes
            links = group.links
            
            interface.new_socket(
                name='Color',
                in_out='INPUT',
                socket_type='NodeSocketColor'
            )
            interface.new_socket(
                name='Hue',
                in_out='INPUT',
                socket_type='NodeSocketFloat'
            )
            interface.new_socket(
                name='Saturation',
                in_out='INPUT',
                socket_type='NodeSocketFloat'
            )
            interface.new_socket(
                name='Value',
                in_out='INPUT',
                socket_type='NodeSocketFloat'
            )
            interface.new_socket(
                name='Shader',
                in_out='OUTPUT',
                socket_type='NodeSocketShader'
            )
                    
            
            eyelid_alb_mix = []
            eyelid_opa_mix = []
            eyelid_nrm_mix = []
            eyelid_rgh_mix = []
            if is_eyelid:
                texture_count = 0
                
                eyelid_matched = False
                eyelid_required_name = base_name
                max_index = 0
                
                iteration = 0
                while not eyelid_matched and len(eyelid_required_name.replace('_', '')) > 1 and iteration < 15:
                    iteration+=1
                    
                    for img_path in path_iterator( path ):
                        if img_path.lower().startswith(base_name.lower()+"_"):
                            eyelid_matched = True
                            for x in range(10):
                                valid =  ("."+str(x)) in img_path and img_path.lower().endswith("opa."+str(x)+".png") or  ("."+str(x)) in img_path and img_path.lower().endswith("alb."+str(x)+".png")
                                if valid:
                                    texture_count += 1
                                    
                                    if x > max_index:
                                        max_index = x
                    if not eyelid_matched:
                        eyelid_required_name = '_'.join(eyelid_required_name.split('_')[:-1])
                        #self.report({'INFO'}, eyelid_required_name)
                
                texture_count = max_index
                #self.report({'INFO'}, 'eyelid texture_count = ' + str(texture_count))
                if texture_count == 0:
                    is_eyelid = False
                else:
                    texture_count+=1
                    
                
                        
            if is_eyelid:
                interface_name = "Eye"
                opa_default = 1
                rgh_default = 0.5
                if "eyelids" in base_name.lower():
                    interface_name = "Eyelids"
                    opa_default = 0
                interface.new_socket(
                    name=interface_name,
                    in_out='INPUT',
                    socket_type='NodeSocketFloat'
                )
                interface.items_tree[5].min_value = 0
                interface.items_tree[5].max_value = texture_count-1

                for x in (range(texture_count)):
                    eyelid_alb_mix.append(nodes.new(type="ShaderNodeMix"))
                    eyelid_opa_mix.append(nodes.new(type="ShaderNodeMix"))
                    eyelid_rgh_mix.append(nodes.new(type="ShaderNodeMix"))
                    eyelid_nrm_mix.append(nodes.new(type="ShaderNodeMix"))
                
                alb_frame = nodes.new(type='NodeFrame')
                alb_frame.label = 'Albedo Textures'
                opa_frame = nodes.new(type='NodeFrame')
                opa_frame.label = 'Alpha Textures'
                rgh_frame = nodes.new(type='NodeFrame')
                rgh_frame.label = 'Roughness Textures'
                nrm_frame = nodes.new(type='NodeFrame')
                nrm_frame.label = 'Normal Map Textures'
                    
                normal_input = nodes.new(type="ShaderNodeNewGeometry")
                normal_input.location = Vector(((-300)-4700, -2100))
                for x in (range(texture_count)):
                    added = nodes.new(type="ShaderNodeMath")
                    links.new(input.outputs[4], added.inputs[0])
                    added.location = Vector(((x*200)-8000, 0))
                    added.inputs[1].default_value = -x+1
                    
                    next_index = x+1;

                    eyelid_alb_mix[x].data_type = "RGBA"
                    eyelid_alb_mix[x].location = Vector(((x*500)-1500, 2500))
                    if len(eyelid_alb_mix) > next_index:
                        links.new(eyelid_alb_mix[x].outputs[2], eyelid_alb_mix[next_index].inputs[6])
                    links.new(added.outputs[0], eyelid_alb_mix[x].inputs[0])
                    eyelid_alb_mix[x].parent = alb_frame
                    
                    
                    eyelid_opa_mix[x].data_type = "FLOAT"
                    if len(eyelid_opa_mix) > next_index:
                        links.new(eyelid_opa_mix[x].outputs[0], eyelid_opa_mix[next_index].inputs[2])
                    links.new(added.outputs[0], eyelid_opa_mix[x].inputs[0])
                    eyelid_opa_mix[x].location = Vector(((x*500)-4700-2500, 1500+450))
                    
                    eyelid_opa_mix[x].inputs[3].default_value = opa_default
                    eyelid_opa_mix[x].inputs[2].default_value = opa_default
                    eyelid_opa_mix[x].parent = opa_frame
                    
                    eyelid_rgh_mix[x].data_type = "FLOAT"
                    if len(eyelid_rgh_mix) > next_index:
                        links.new(eyelid_rgh_mix[x].outputs[0], eyelid_rgh_mix[next_index].inputs[2])
                    links.new(added.outputs[0], eyelid_rgh_mix[x].inputs[0])
                    eyelid_rgh_mix[x].location = Vector(((x*500)-7200, 2450))
                    
                    eyelid_rgh_mix[x].inputs[3].default_value = rgh_default
                    eyelid_rgh_mix[x].inputs[2].default_value = rgh_default
                    eyelid_rgh_mix[x].parent = rgh_frame
                    
                    
                    eyelid_nrm_mix[x].data_type = "VECTOR"
                    links.new(normal_input.outputs['Normal'], eyelid_nrm_mix[x].inputs[5])
                    if len(eyelid_nrm_mix) > next_index:
                        links.new(eyelid_nrm_mix[x].outputs[1], eyelid_nrm_mix[next_index].inputs[4])
                    if x == 0:
                        links.new(normal_input.outputs['Normal'], eyelid_nrm_mix[x].inputs[4])
                    links.new(added.outputs[0], eyelid_nrm_mix[x].inputs[0])
                    eyelid_nrm_mix[x].location = Vector(((x*500)-4700, -1800))
                    eyelid_nrm_mix[x].parent = nrm_frame

            
            bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
            bsdf.location = Vector((100.0, 0.0))
            links.new(bsdf.outputs[0], output.inputs[0])
            tree.links.new(group_node.outputs[0], shader_output.inputs[0])
            
            use_tcl = False
            unused_frame = None
            mix_node = None
            alb_node = None
            emm_node = None
            inka_color = (self.ink_A[0], self.ink_A[1], self.ink_A[2], 1)
            
            group_node.inputs[0].default_value = inka_color
            group_node.inputs[1].default_value = 0.5
            group_node.inputs[2].default_value = 1
            group_node.inputs[3].default_value = 1
            
            if 'roll' in base_name.lower() or 'tank' in base_name.lower():
                links.new(input.outputs[0], bsdf.inputs['Base Color'])
                use_tcl = True
            
            unused_iteration = 0
            texture_matched = False
            iteration = 0
            
            #self.report({'INFO'}, 'Material base_name = '+base_name.lower())
            while not texture_matched and len(base_name.replace('_', '')) > 1 and iteration < 6:
                iteration+=1
                
                for img_path in path_iterator( path ):
                    #self.report({'INFO'}, str(img_path.lower().replace('obj_', '')))
                    path_check = img_path.lower().replace('obj_', '')
                    path_match = path_check.startswith(base_name.lower()+"_") or base_name.startswith(path_check.lower())
                    if iteration > 1:
                        path_match = path_check.lower().startswith(base_name.lower()) or base_name.lower().startswith(path_check.lower())

                    if path_match:
                        texture_matched = True
                        full_path = os.path.join( path, img_path )
                        
                        bpy.ops.image.open(filepath = full_path)
                        img_node = nodes.new(type="ShaderNodeTexImage")
                        img_node.image = bpy.data.images.load(filepath = full_path)
                        
                        # Eyelid
                        eyelid_index = 0
                        if is_eyelid:
                            for x in range(texture_count):
                                if ("."+str(x)) in img_path:
                                    eyelid_index = x
                                    img_path = img_path.replace("."+str(x)+".png", ".png")
                            #self.report({'INFO'}, 'Eyelid name conversion to '+ img_path)
                            
                        # Check Type
                        if img_path.lower().endswith("tcl.png") or img_path.lower().endswith("_Mask_Resi.png"):
                            mix_node = nodes.new(type="ShaderNodeMix")
                            mix_node.data_type = "RGBA"
                            mix_node.inputs[7].default_value = (self.ink_A.r, self.ink_A.g, self.ink_A.b, 1)
                            links.new(input.outputs[0], mix_node.inputs[7])
                            
                            img_node.image.colorspace_settings.name = 'Non-Color'
                            
                            links.new(img_node.outputs[0], mix_node.inputs[0])
                            
                            if alb_node != None:
                                if is_eyelid:
                                    links.new(mix_node.outputs[2], eyelid_alb_mix[eyelid_index].inputs[7])
                                else:
                                    links.new(mix_node.outputs[2], bsdf.inputs['Base Color'])
                                links.new(alb_node.outputs[0], mix_node.inputs[6])
                                
                            img_node.location = Vector((-900.0, 1600.0))
                            mix_node.location = Vector((-600.0, 1300.0))
                            
                            use_tcl = True
                        
                        if img_path.lower().endswith("alb.png"):
                            hue_node = nodes.new(type="ShaderNodeHueSaturation");
                            hue_node.location = Vector((-900.0, 1300.0))
                            alb_node = hue_node
                            
                            # hue_node.inputs['Hue'].default_value = self.hue
                            links.new(input.outputs['Hue'], hue_node.inputs['Hue'])
                            links.new(input.outputs['Saturation'], hue_node.inputs['Saturation'])
                            links.new(input.outputs['Value'], hue_node.inputs['Value'])
                            
                            links.new(img_node.outputs[0], hue_node.inputs['Color'])
                            if is_eyelid:
                                links.new(hue_node.outputs[0], eyelid_alb_mix[eyelid_index].inputs[7])
                                img_node.parent = alb_frame
                                hue_node.parent = alb_frame
                            else:
                                links.new(hue_node.outputs[0], bsdf.inputs['Base Color'])
                            
                            
                            if mix_node != None:
                                if is_eyelid:
                                    links.new(mix_node.outputs[2], eyelid_alb_mix[eyelid_index].inputs[7])
                                else:
                                    links.new(mix_node.outputs[2], bsdf.inputs['Base Color'])
                                links.new(hue_node.outputs[0], mix_node.inputs[6])
                                mix_node.location = Vector((-600.0, 1300.0))
                            
                            if is_eyelid:
                                hue_node.location = Vector(((eyelid_index*500)-1500, 2500)) + Vector((-300, 500))
                                img_node.location = Vector(((eyelid_index*500)-1500, 2500)) + Vector((-600, 500))
                            else:
                                img_node.location = Vector((-1200.0, 1300.0))
                                hue_node.location = Vector((-900.0, 1300.0))
                                
                            if image_has_alpha(img_node.image) and not bsdf.inputs['Alpha'].links:
                                links.new(img_node.outputs['Alpha'], bsdf.inputs['Alpha'])
                                bpy.context.object.active_material.blend_method = blend_method
                                bpy.context.object.active_material.shadow_method = 'CLIP'
                                    
                        if img_path.lower().endswith("mtl.png"):
                            img_node.image.colorspace_settings.name = 'Non-Color'
                            links.new(img_node.outputs[0], bsdf.inputs['Metallic'])
                            img_node.location = Vector((-900.0, 700.0))
                                    
                        if img_path.lower().endswith("spc.png"):
                            img_node.image.colorspace_settings.name = 'Non-Color'
                            links.new(img_node.outputs[0], bsdf.inputs['Specular'])
                            img_node.location = Vector((-600.0, 400.0))
                                    
                        if img_path.lower().endswith("rgh.png"):
                            img_node.image.colorspace_settings.name = 'Non-Color'
                            img_node.location = Vector((-900.0, 100.0))
                            
                            if is_eyelid:
                                links.new(img_node.outputs[0], eyelid_rgh_mix[eyelid_index].inputs[3])
                                img_node.location = Vector(((eyelid_index*500)-4700-2500, 1500+950)) + Vector((-600, 500))
                                img_node.parent = rgh_frame
                            else:
                                links.new(img_node.outputs[0], bsdf.inputs['Roughness'])
                                    
                        if img_path.lower().endswith("emm.png"):
                            links.new(img_node.outputs[0], bsdf.inputs['Emission Strength'])
                            if not self.emission_color:
                                img_node.image.colorspace_settings.name = 'Non-Color'
                                bsdf.inputs['Emission Color'].default_value = (self.ink_A.r, self.ink_A.g, self.ink_A.b, 1)
                                links.new(input.outputs[0], bsdf.inputs['Emission Color'])
                                use_tcl = True
                            else:
                                links.new(img_node.outputs[0], bsdf.inputs['Emission Color'])
                            img_node.location = Vector((-900.0, -500.0))
                            
                        if img_path.lower().endswith("emi.png"):
                            bsdf.inputs['Emission Strength'].default_value = 1
                            links.new(img_node.outputs[0], bsdf.inputs['Emission Color'])
                            img_node.location = Vector((-900.0, -500.0))
                                        
                        if img_path.lower().endswith("opa.png"):
                            img_node.image.colorspace_settings.name = 'Non-Color'
                            img_node.location = Vector((-600.0, -200.0))
                            
                            if is_eyelid:
                                #self.report({'INFO'}, 'Eyelid Index = '+str(eyelid_index))
                                links.new(img_node.outputs[0], eyelid_opa_mix[eyelid_index].inputs[3])
                                img_node.location = Vector(((eyelid_index*500)-4700-2500, 1500+950)) + Vector((-600, 500))
                                img_node.parent = opa_frame
                            else:
                                links.new(img_node.outputs[0], bsdf.inputs['Alpha'])
                                
                            bpy.context.object.active_material.blend_method = blend_method
                            bpy.context.object.active_material.shadow_method = 'CLIP'
                            
                        if img_path.lower().endswith("alp.png"):
                            img_node.image.colorspace_settings.name = 'Non-Color'
                            img_node.location = Vector((-600.0, -200.0))
                            
                            if is_eyelid:
                                links.new(img_node.outputs[0], eyelid_opa_mix[eyelid_index].inputs[3])
                                img_node.location = Vector(((eyelid_index*500)-4700-2500, 1500+950)) + Vector((-600, 500))
                                img_node.parent = opa_frame
                            else:
                                links.new(img_node.outputs[0], bsdf.inputs['Alpha'])
                                
                            bpy.context.object.active_material.blend_method = blend_method
                            bpy.context.object.active_material.shadow_method = 'CLIP'
                    
                        if img_path.lower().endswith("nrm.png"):
                            nrm_node = nodes.new("ShaderNodeNormalMap")
                            img_node.image.colorspace_settings.name = 'Non-Color'
                            links.new(img_node.outputs[0], nrm_node.inputs[1])
                            nrm_node.location = Vector((-600.0, -800.0))
                            img_node.location = Vector((-900.0, -800.0))
                            
                            if is_eyelid:
                                links.new(nrm_node.outputs[0], eyelid_nrm_mix[eyelid_index].inputs[5])
                                nrm_node.location = Vector(((eyelid_index*500)-4700, -1800)) + Vector((-300, 500))
                                img_node.location = Vector(((eyelid_index*500)-4700, -1800)) + Vector((-600, 500))
                                img_node.parent = nrm_frame
                                nrm_node.parent = nrm_frame
                            else:
                                if self.inverse_nrm:
                                    invert = nodes.new('ShaderNodeInvert')
                                    links.new(img_node.outputs[0], invert.inputs['Color'])
                                    links.new(invert.outputs[0], nrm_node.outputs[0])
                                    invert.location = Vector((-400.0, -800.0))
                                links.new(nrm_node.outputs[0], bsdf.inputs['Normal'])
                            
                            nrm_node.space = self.normal_space

                        
                        # Unused Nodes
                        if not img_node.outputs[0].links:
                            if unused_frame == None:
                                unused_frame = nodes.new(type='NodeFrame')
                                unused_frame.label = 'Unused Textures'
                            
                            img_node.location = Vector((500 + unused_iteration*310, -300))
                            unused_iteration += 1
                            img_node.parent = unused_frame
                        
                
                    if mix_node != None:
                        links.new(mix_node.outputs[2], bsdf.inputs["Base Color"])
                    elif alb_node != None and not is_eyelid:
                        #alb_node.image.name = bpy.context.active_object.active_material.name + "_alb"
                        links.new(alb_node.outputs["Color"], bsdf.inputs["Base Color"])
                    elif mix_node == None and alb_node == None:
                        bsdf.inputs["Base Color"].default_value = (0,0,0,1)
                    
                if not texture_matched and iteration > 1:
                    base_name = '_'.join(base_name.split('_')[:-1])
                    #self.report({'INFO'}, 'new = '+base_name)
                    #self.report({'INFO'}, str(len(base_name.replace('_', ''))))
                    #self.report({'INFO'}, base_name.replace('_', ''))
                else:
                    if is_eyelid:
                        links.new(eyelid_alb_mix[len(eyelid_alb_mix)-1].outputs[2], bsdf.inputs['Base Color'])
                        links.new(eyelid_opa_mix[len(eyelid_opa_mix)-1].outputs[0], bsdf.inputs['Alpha'])
                        links.new(eyelid_rgh_mix[len(eyelid_rgh_mix)-1].outputs[0], bsdf.inputs['Roughness'])
                        
                        if self.inverse_nrm:
                            invert = nodes.new('ShaderNodeInvert')
                            links.new(eyelid_nrm_mix[len(eyelid_nrm_mix)-1].outputs[1], invert.inputs['Color'])
                            links.new(invert.outputs[0], bsdf.inputs['Normal'])
                        else:
                            links.new(eyelid_nrm_mix[len(eyelid_nrm_mix)-1].outputs[1], bsdf.inputs['Normal'])
                        
                        for mix in eyelid_alb_mix:
                            if not mix.inputs[7].links and alb_node != None:
                                links.new(alb_node.outputs[0], mix.inputs[7])
                                
                            
                    if not use_tcl and 'Color' in interface.items_tree:
                        interface.remove(item=interface.items_tree['Color'])
                # End of Texture Schearching
        
        
        if child.name.startswith("mouth") and not child.name.startswith("mouth0"):
            child.hide_viewport = True
            child.hide_render = True
        
        reconstitued_materials.append(bpy.context.active_object.active_material)
                    
                
    if model_armature != None:
        bpy.ops.object.select_all(action='DESELECT')
        model_armature.select_set(True)
        bpy.context.view_layer.objects.active = model_armature
    if nameToReset:
        self.name = ""
    return {'FINISHED'}

def print(self, text, type = 'INFO'):
    self.report({'INFO'}, str(text))
    
def image_has_alpha(img):
    b = 32 if img.is_float else 8
    return (
        img.depth == 2*b or   # Grayscale+Alpha
        img.depth == 4*b      # RGB+Alpha
    )

from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty, FloatVectorProperty
from bpy.types import Operator

class import_splatoon_item(Operator, ImportHelper):
    bl_idname = "import_splatoon.item"
    bl_label = "Import Splatoon Model"


    filter_glob: StringProperty(
        default="*.fbx;*.dae",
        options={'HIDDEN'},
        maxlen=255,
    )
    
    name: StringProperty(
        default="",
        name="Name",
        maxlen=100,
        description="The name of the model"
    )

    ink_A: FloatVectorProperty(
        name="Team Color",
        description="The ink color of the imported item",
        default=(1, 0, 0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    
    basic_optimisation: BoolProperty(
        name="Basic Optimization",
        description="Connect the faces and reduce vertices number",
        default=True
    )
    deep_optimisation: BoolProperty(
        name="Clean Vertices",
        description="Remove every non connected vertices generated by the model extractor",
        default=True
    )
    
    armature_modif: BoolProperty(
        name="Auto Correct Armature",
        description="Makes the armature more easy to use and to visualize",
        default=True
    )
    bone_orient: BoolProperty(
        name="Auto Orient Bones",
        description="Makes bones orientation more logical",
        default=True
    )
    
    attach: EnumProperty(
        name="Attach to Charactere",
        description="Auto attach the object to the hand of the selected inkling/octoling",
        items=(
            ('none', "No", ""),
            ('Weapon_R', "Right Hand", ""),
            ('Weapon_L', "Left Hand", "")
        ),
        default="none"
    )
    
    inverse_nrm: BoolProperty(
        name="Inverse Normal Map",
        description="Reverse the normal map texture, usually for maps models",
        default=False
    )
    
    normal_space: EnumProperty(
        name="Normal Map Space",
        description="The space of the normal map texture",
        items=(
            ('TANGENT', 'Tangent', ''),
            ('BLENDER_WORLD', 'World', 'Blender World Space'),
            ('OBJECT', 'Object', '')
        )
    )
    
    emission_color: BoolProperty(
        name="Use Emission as Emission Color",
        description="Do the emission texture use colors",
        default=False
    )
    
    alpha_clip: BoolProperty(
        name="Alpha Clip",
        description="Do the material alpha is clipped",
        default=False
    )

    def execute(self, context):
        return import_item(self)


def menu_func_import(self, context):
    self.layout.operator(import_splatoon_item.bl_idname, text="Splatoon Model")

def register():
    bpy.utils.register_class(import_splatoon_item)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
def unregister():
    bpy.utils.unregister_class(import_splatoon_item)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
if __name__ == "__main__":
    register()
    
    
    
    
    
# TO DELETE:
#bpy.ops.object.select_all(action='SELECT')
#bpy.ops.object.delete(use_global=False)
#bpy.ops.outliner.orphans_purge(num_deleted=50, do_local_ids=True, do_linked_ids=True, do_recursive=True)