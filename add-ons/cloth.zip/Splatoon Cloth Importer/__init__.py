bl_info = {
    "name": "Splatoon Cloth",
    "author": "Coconuts XXS",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "File > Import > Splatoon 3 Cloth",
    "description": "Import Splatoon 3 cloth model.",
    "warning": "",
    "doc_url": "",
    "category": "Import",
}

import bpy
import os
from pathlib import Path
from bpy.utils import resource_path
from mathutils import Vector

USER = Path(resource_path('USER'))
ADDON = "Splatoon Cloth"

srcPath = USER / "scripts" / "addons" / ADDON

def path_iterator(folder_path):
    for fp in os.listdir(folder_path):
        if fp.endswith( tuple( bpy.path.extensions_image ) ):
            yield fp
        
def transparencify(mat, armature, output_index = 0):
    def cycle(tree, enter=False):
        nodes=tree.nodes.values()
        links=tree.links
        output = None
        mix = None
        for node in nodes:
            print(node.type)
            if node.type == 'GROUP' and enter:
                print(node.node_tree)
                cycle(node.node_tree)
                break
            if enter:
                continue
            if node.type == 'GROUP_OUTPUT':
                output = node
                mix=tree.nodes.new('ShaderNodeMixShader')
                mix.location = Vector((600, 600))
                trans=tree.nodes.new('ShaderNodeBsdfTransparent')
                trans.location = Vector((300, 500))
                output.location = Vector((800, 0))
                links.new(trans.outputs[0], mix.inputs[2])
                for node_links in output.inputs[output_index].links:
                    bsdf=node_links.from_node
                links.new(bsdf.outputs[0], mix.inputs[1])
                links.new(mix.outputs[0], output.inputs[output_index])
                tree.interface.new_socket(
                    name='Transparency',
                    in_out='INPUT',
                    socket_type='NodeSocketFloat'
                )
        if not enter and mix != None:
            for node in nodes:
                if node.type == 'GROUP_INPUT':
                    links.new(node.outputs['Transparency'], mix.inputs[0])


    mat.blend_method = 'BLEND'
    mat.shadow_method = 'HASHED'
    mat.show_transparent_back = False

    cycle(mat.node_tree, True)
    for node in mat.node_tree.nodes:
        if node.type == 'GROUP':
            driver = node.inputs['Transparency'].driver_add('default_value').driver
            v = driver.variables.new()
            v.name = 'Transparency'
            v.targets[0].id = armature
            v.targets[0].bone_target = "Transparency"
            v.type = 'TRANSFORMS'
            v.targets[0].transform_space = 'LOCAL_SPACE'
            v.targets[0].transform_type = 'LOC_Y'
            driver.expression = v.name
            

def import_clt(self):
    path = str(os.path.split(self.filepath)[0]) + "/"
    file = str(os.path.split(self.filepath)[1])
    armature = bpy.context.view_layer.objects.active
    use_armature = True

    if len(self.name) == 0:
        self.name = path.split("/")[-2]
    
    if armature != None:
        if armature.type != "ARMATURE":
            self.report({'WARNING'}, 'To add a cloth to a charactere select his armature and import again')
            use_armature = False
            # return {'FININSHED'}
    else:
        self.report({'WARNING'}, 'To add a cloth to a charactere select his armature and import again')
        use_armature = False
        # return {'FININSHED'}
    
    mask_path = str(srcPath) + "/GearAlphaMask/" + self.mask_type
    mask_shs_path = str(srcPath) + "/GearAlphaMask/" + self.mask_type_shs
    
    bpy.ops.object.select_all(action='DESELECT')
    
    bpy.ops.wm.collada_import(filepath = path+file)
    
    for o in bpy.context.selected_objects:
        if o.type == "LIGHT":
            bpy.data.objects.remove(bpy.data.objects[o.name], do_unlink=True)
            #o.delete()
        elif o.type == "ARMATURE":
            obj = o
    
    obj.name = self.name
    
    if use_armature:
        obj.location = armature.location
    
    body_mesh = None
    
    if use_armature:
        for armature_child in armature.children:
            if "Body" in armature_child.active_material.name and not "Hif" in armature_child.active_material.name:
                body_mesh = armature_child
    
    # CLOTH :
    if self.cloth_type == "clt":
        # TRANSFORMING
        if use_armature:
            # bpy.ops.transform.resize(value=(4.85 * armature.scale.x, 4.85 * armature.scale.y, 4.85 * armature.scale.z))
            bpy.ops.rotation_euler = armature.rotation_euler
            bpy.ops.transform.translate(value=(0, 0.82 * armature.scale.y, 0), orient_type='LOCAL')
    
        # MASK
        if self.mask_type != "none":
            bpy.ops.image.open(filepath = mask_path)
        
            mask_node = body_mesh.active_material.node_tree.nodes.new(type="ShaderNodeTexImage")
            mask_node.image = bpy.data.images[self.mask_type]
            mask_node.image.colorspace_settings.name = 'Non-Color'
            body_mesh.active_material.node_tree.links.new(mask_node.outputs[0], body_mesh.active_material.node_tree.nodes["Group"].inputs['Cloth_Mask'])
    
    # SHOOES
    if self.cloth_type == "shs":
        # TRANSFORMING
        if use_armature:
            # bpy.ops.transform.resize(value=(5.1 * armature.scale.x, 5.1 * armature.scale.y, 5.1 * armature.scale.z))
            bpy.ops.rotation_euler = armature.rotation_euler
            bpy.ops.transform.translate(value=(0.097/2, 0, 0.04), orient_type='LOCAL')
    
    
        # MASK
        if self.mask_type_shs != "none":
            bpy.ops.image.open(filepath = mask_shs_path)
        
            mask_node = body_mesh.active_material.node_tree.nodes.new(type="ShaderNodeTexImage")
            mask_node.image = bpy.data.images[self.mask_type_shs]
            mask_node.image.colorspace_settings.name = 'Non-Color'
            body_mesh.active_material.node_tree.links.new(mask_node.outputs[0], body_mesh.active_material.node_tree.nodes["Group"].inputs['Shooes_Mask'])
            
    # HEAD
    if self.cloth_type == "head":
        # TRANSFORMING
        if use_armature:
            # bpy.ops.transform.resize(value=(4.85 * armature.scale.x, 4.85 * armature.scale.y, 4.85 * armature.scale.z))
            bpy.ops.rotation_euler = armature.rotation_euler
            bpy.ops.transform.translate(value=(0, 1.2523 * armature.scale.y, 0), orient_type='LOCAL')
    
    bpy.ops.object.scale_clear(clear_delta=False)

    #RIGING
    for child in obj.children:
        bpy.ops.object.select_all(action='DESELECT')
        child.select_set(True)
        bpy.context.view_layer.objects.active = child
        
        if use_armature:
            bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
            
            armature.select_set(True)
            bpy.context.view_layer.objects.active = armature
        
            bpy.ops.object.parent_set(type='ARMATURE')
        
            bpy.ops.object.select_all(action='DESELECT')
            child.select_set(True)
            bpy.context.view_layer.objects.active = child
        

        bpy.ops.object.editmode_toggle()
        if self.clean:
            clean(child)
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.remove_doubles(threshold=0.001, use_unselected=True, use_sharp_edge_from_normals=True)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.editmode_toggle()
        
        if self.cloth_type == "clt" and use_armature:
            bpy.context.object.location = (armature.location.x, armature.location.y, 0.82 + armature.location.z)
        elif self.cloth_type == "shs":
            height = 0.4213
            if self.shooe_height == 'ankle':
                height = 0.4213/2
            if use_armature:
                bpy.context.object.location = (0.097+armature.location.x, armature.location.y+-0, height + armature.location.z)
        elif self.cloth_type == "head" and use_armature:
            bpy.context.object.location = (armature.location.x, armature.location.y, 1.2523 + armature.location.z)
            
        bpy.ops.object.scale_clear(clear_delta=False)
        
        if use_armature:
            bpy.ops.object.modifier_add(type='VERTEX_WEIGHT_MIX')
            bpy.context.object.modifiers[2].mix_set = 'ALL'
            bpy.context.object.modifiers[2].mix_mode = 'ADD'
            bpy.context.object.modifiers[2].vertex_group_a = "arm1_L"
            bpy.context.object.modifiers[2].vertex_group_b = "arm1sub_L"
            if bpy.context.object.modifiers["VertexWeightMix"].is_active == False:
                bpy.ops.object.modifier_apply(modifier="VertexWeightMix", report=True)
            else:
                bpy.ops.object.modifier_remove(modifier="VertexWeightMix", report=True)
            
            bpy.ops.object.modifier_add(type='VERTEX_WEIGHT_MIX')
            bpy.context.object.modifiers[2].mix_set = 'ALL'
            bpy.context.object.modifiers[2].mix_mode = 'ADD'
            bpy.context.object.modifiers[2].vertex_group_a = "arm1_R"
            bpy.context.object.modifiers[2].vertex_group_b = "arm1sub_R"
            if bpy.context.object.modifiers["VertexWeightMix"].is_active == False:
                bpy.ops.object.modifier_apply(modifier="VertexWeightMix", report=True)
            else:
                bpy.ops.object.modifier_remove(modifier="VertexWeightMix", report=True)
            
            bpy.ops.object.modifier_add(type='VERTEX_WEIGHT_MIX')
            bpy.context.object.modifiers[2].mix_set = 'ALL'
            bpy.context.object.modifiers[2].mix_mode = 'ADD'
            bpy.context.object.modifiers[2].vertex_group_a = "crotch_L"
            bpy.context.object.modifiers[2].vertex_group_b = "leg1_L"
            if bpy.context.object.modifiers["VertexWeightMix"].is_active == False:
                bpy.ops.object.modifier_apply(modifier="VertexWeightMix", report=True)
            else:
                bpy.ops.object.modifier_remove(modifier="VertexWeightMix", report=True)
            
            bpy.ops.object.modifier_add(type='VERTEX_WEIGHT_MIX')
            bpy.context.object.modifiers[2].mix_set = 'ALL'
            bpy.context.object.modifiers[2].mix_mode = 'ADD'
            bpy.context.object.modifiers[2].vertex_group_a = "crotch_R"
            bpy.context.object.modifiers[2].vertex_group_b = "leg1_R"
            if bpy.context.object.modifiers["VertexWeightMix"].is_active == False:
                bpy.ops.object.modifier_apply(modifier="VertexWeightMix", report=True)
            else:
                bpy.ops.object.modifier_remove(modifier="VertexWeightMix", report=True)

        
        name_list = [
            ['root', 'Head'],
            ['Root', 'Head'],
            ['joint_root','Spawner_Root'],
            ['hip','Waist'],
            ['spine1','Spine_1'],
            ['spine2','Spine_2'],
            ['chest','Spine_3'],
            ['shoulder_L','Clavicle_L'],
            ['arm1_L','Arm_1_L'],
            ['arm2_L','Arm_2_L'],
            ['hand_L','Wrist_L'],
            ['shoulder_R','Clavicle_R'],
            ['arm1_R','Arm_1_R'],
            ['arm2_R','Arm_2_R'],
            ['hand_R','Wrist_R'],
            ['head','Head'],
            ['leg1_L','Leg_1_L'],
            ['leg1_R','Leg_1_R'],
            ['fingerA1_L', 'Finger_B_1_L'],
            ['fingerA2_L', 'Finger_B_2_L'],
            ['fingerB1_L', 'Finger_C_1_L'],
            ['fingerB2_L', 'Finger_C_2_L'],
            ['thumb_L', 'Finger_A_1_L'],
            ['fingerA1_R', 'Finger_B_1_R'],
            ['fingerA2_R', 'Finger_B_2_R'],
            ['fingerB1_R', 'Finger_C_1_R'],
            ['fingerB2_R', 'Finger_C_2_R'],
            ['thumb_R', 'Finger_A_1_R'],
            ['leg2sub_L', 'Leg_2_L'],
            ['foot_L', 'Ankle_L'],
            ['toe_L', 'Toe_L'],
            ['leg2sub_R', 'Leg_2_R'],
            ['foot_R', 'Ankle_R'],
            ['toe_R', 'Toe_R'],
        ]

        v_groups = child.vertex_groups
        for n in name_list:
            if n[0] in v_groups:
                if v_groups[n[0]] != None:
                    v_groups[n[0]].name = n[1]
        
        
        bpy.ops.object.select_all(action='DESELECT')
        child.select_set(True)
        bpy.context.view_layer.objects.active = child
        
        if use_armature:
            bpy.ops.object.modifier_remove(modifier="Armature", report=True)
        
        # SHADING
        base_name = bpy.context.active_object.active_material.name
        to_edit=True
        
        if bpy.context.active_object.active_material.name.startswith("Obj_"):
            base_name = base_name[4:]
        
        tree = bpy.context.active_object.active_material.node_tree
        
        for node in tree.nodes:
            tree.nodes.remove(node)
    
        shader_output = tree.nodes.new(type="ShaderNodeOutputMaterial")
        shader_output.location = Vector((600.0, 0.0))
            
        group = bpy.data.node_groups.new(bpy.context.active_object.active_material.name, 'ShaderNodeTree')
        group_node = tree.nodes.new("ShaderNodeGroup")
        group_node.node_tree = group
        
        interface = group.interface
        
        input = group.nodes.new('NodeGroupInput')
        output = group.nodes.new('NodeGroupOutput')
        
        input.location = Vector((-2500, 0))
        output.location = Vector((2500, 0))
        
        nodes = group.nodes
        links = group.links
        
        interface.new_socket(
            name='Color',
            in_out='INPUT',
            socket_type='NodeSocketColor'
        )
        interface.new_socket(
            name='Hue',
            in_out='INPUT',
            socket_type='NodeSocketFloat'
        )
        interface.new_socket(
            name='Saturation',
            in_out='INPUT',
            socket_type='NodeSocketFloat'
        )
        interface.new_socket(
            name='Value',
            in_out='INPUT',
            socket_type='NodeSocketFloat'
        )
        interface.new_socket(
            name='Shader',
            in_out='OUTPUT',
            socket_type='NodeSocketShader'
        )
                
        bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
        bsdf.location = Vector((100.0, 0.0))
        links.new(bsdf.outputs[0], output.inputs[0])
        tree.links.new(group_node.outputs[0], shader_output.inputs[0])
        
        use_tcl = False
        unused_frame = None
        mix_node = None
        alb_node = None
        emm_node = None
        inka_color = (self.ink_A[0], self.ink_A[1], self.ink_A[2], 1)
        
        group_node.inputs[0].default_value = inka_color
        group_node.inputs[1].default_value = 0.5
        group_node.inputs[2].default_value = 1
        group_node.inputs[3].default_value = 1
        
        self.report({'INFO'}, base_name)
        
        unused_iteration = 0
        
        ### OLD
        if False:
            nodes = bpy.context.active_object.active_material.node_tree.nodes
            links = bpy.context.active_object.active_material.node_tree.links
            
            for node in nodes:
                nodes.remove(node)
            
            output = nodes.new(type="ShaderNodeOutputMaterial")
            bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
            links.new(bsdf.outputs[0], output.inputs[0])
            
            alb_node = None
            mix_node = None
            
        for x in range(999):
            if bpy.context.active_object.active_material.name.endswith("."+("{:03d}".format(x))):
                base_name = bpy.context.active_object.active_material.name[:-4]
        
        if bpy.context.active_object.active_material.name.startswith("Obj_"):
            bpy.context.active_object.active_material.name = bpy.context.active_object.active_material.name[4:]
            base_name = bpy.context.active_object.active_material.name
            
        # Glass Specificity
        if "glass" in bpy.context.active_object.active_material.name:
            bsdf.inputs['Transmission Weight'].default_value = 1
            bsdf.inputs['Alpha'].default_value = 0.3
            bsdf.inputs['Roughness'].default_value = 0.3
            bsdf.inputs['Sheen Weight'].default_value = 0.5
            bpy.context.object.active_material.blend_method = 'BLEND'
            bpy.context.object.active_material.blend_method = 'BLEND'
            
        if bpy.context.active_object.active_material.name.endswith('body'):
            bpy.context.active_object.active_material.name = bpy.context.active_object.active_material.name[:-4]

        bpy.context.active_object.active_material.name = base_name + " - " + self.name
        if bpy.context.active_object.active_material.name.lower().startswith("m_"):
            bpy.context.active_object.active_material.name = bpy.context.active_object.active_material.name[2:]
            
            
        self.report({"INFO"}, base_name)
        
        is_eyelid = False
        ink_noise = None
        
        for img_path in path_iterator( path ):
            if img_path.lower().startswith(base_name.lower()+"_"):
                full_path = os.path.join( path, img_path )
                    
                bpy.ops.image.open(filepath = full_path)
                img_node = nodes.new(type="ShaderNodeTexImage")
                img_node.image = bpy.data.images.load(filepath = full_path)
                
                if img_path.lower().endswith("tcl.png"):
                    mix_node = nodes.new(type="ShaderNodeMix")
                    mix_node.data_type = "RGBA"
                    mix_node.inputs[7].default_value = (self.ink_A.r, self.ink_A.g, self.ink_A.b, 1)
                    links.new(input.outputs[0], mix_node.inputs[7])
                    
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    
                    links.new(img_node.outputs[0], mix_node.inputs[0])
                    
                    if alb_node != None:
                        if is_eyelid:
                            links.new(mix_node.outputs[2], eyelid_alb_mix[eyelid_index].inputs[7])
                        else:
                            links.new(mix_node.outputs[2], bsdf.inputs['Base Color'])
                        links.new(alb_node.outputs[0], mix_node.inputs[6])
                        
                    img_node.location = Vector((-900.0, 1600.0))
                    mix_node.location = Vector((-600.0, 1300.0))
                    
                    use_tcl = True
                
                if img_path.lower().endswith("alb.png"):
                    hue_node = nodes.new(type="ShaderNodeHueSaturation");
                    hue_node.location = Vector((-900.0, 1300.0))
                    alb_node = hue_node
                    
                    # hue_node.inputs['Hue'].default_value = self.hue
                    links.new(input.outputs[1], hue_node.inputs['Hue'])
                    links.new(input.outputs[2], hue_node.inputs['Saturation'])
                    links.new(input.outputs[3], hue_node.inputs['Value'])
                    
                    links.new(img_node.outputs[0], hue_node.inputs['Color'])
                    links.new(hue_node.outputs[0], bsdf.inputs['Base Color'])
                    
                    
                    if mix_node != None:
                        links.new(mix_node.outputs[2], bsdf.inputs['Base Color'])
                        links.new(hue_node.outputs[0], mix_node.inputs[6])
                        mix_node.location = Vector((-600.0, 1300.0))
                    
                    img_node.location = Vector((-1200.0, 1300.0))
                    hue_node.location = Vector((-900.0, 1300.0))
                            
                if img_path.lower().endswith("mtl.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Metallic'])
                    img_node.location = Vector((-900.0, 700.0))
                            
                if img_path.lower().endswith("spc.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Specular'])
                    img_node.location = Vector((-600.0, 400.0))
                            
                if img_path.lower().endswith("rgh.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Roughness'])
                    img_node.location = Vector((-900.0, 100.0))
                            
                if img_path.lower().endswith("emm.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Emission Strength'])
                    bsdf.inputs['Emission Color'].default_value = (self.ink_A.r, self.ink_A.g, self.ink_A.b, 1)
                    links.new(input.outputs[0], bsdf.inputs['Emission Color'])
                    img_node.location = Vector((-900.0, -500.0)) # AAAAAA
                    use_tcl = True
                                
                if img_path.lower().endswith("opa.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    img_node.location = Vector((-600.0, -200.0))
                    
                    links.new(img_node.outputs[0], bsdf.inputs['Alpha'])
                    
                if img_path.lower().endswith("alp.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    img_node.location = Vector((-600.0, -200.0))
                    
                    links.new(img_node.outputs[0], bsdf.inputs['Alpha'])
            
                if img_path.lower().endswith("nrm.png"):
                    nrm_node = nodes.new("ShaderNodeNormalMap")
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], nrm_node.inputs[1])
                    nrm_node.location = Vector((-600.0, -800.0))
                    img_node.location = Vector((-900.0, -800.0))
                    
                    links.new(nrm_node.outputs[0], bsdf.inputs['Normal'])
                if img_path.lower().endswith("2cl.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    ink_noise = img_node
                
                # Unused Nodes
                if not img_node.outputs[0].links and not img_path.lower().endswith("2cl.png"):
                    if unused_frame == None:
                        unused_frame = nodes.new(type='NodeFrame')
                        unused_frame.label = 'Unused Textures'
                    
                    img_node.location = Vector((500 + unused_iteration*310, -300))
                    unused_iteration += 1
                    img_node.parent = unused_frame
                    
                    
                
                continue
                ### OLD
                full_path = os.path.join( path, img_path )
                
                bpy.ops.image.open(filepath = full_path)
                        
                img_node = nodes.new(type="ShaderNodeTexImage")
                img_node.image = bpy.data.images[img_path]
                
                # links.new(img_node.outputs[0], bsdf.inputs[0])
                
                if img_path.endswith("Tcl.png"):
                    mix_node = nodes.new(type="ShaderNodeMix")
                    mix_node.data_type = "RGBA"
                    mix_node.inputs[7].default_value = (self.ink_A.r, self.ink_A.g, self.ink_A.b, 1)
                    
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    
                    links.new(img_node.outputs[0], mix_node.inputs[0])
                    
                    if alb_node != None:
                        links.new(mix_node.outputs[2], bsdf.inputs['Base Color'])
                        links.new(alb_node.outputs[0], mix_node.inputs[6])
                
                if img_path.endswith("Alb.png"):
                    alb_node = img_node
                    hue_node = nodes.new(type="ShaderNodeHueSaturation");
                    
                    hue_node.inputs['Hue'].default_value = self.hue
                    
                    links.new(img_node.outputs[0], hue_node.inputs['Color'])
                    links.new(hue_node.outputs[0], bsdf.inputs['Base Color'])
                    
                    if mix_node != None:
                        links.new(mix_node.outputs[2], bsdf.inputs['Base Color'])
                        links.new(hue_node.outputs[0], mix_node.inputs[6])
                            
                if img_path.endswith("Mtl.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Metallic'])
                            
                if img_path.endswith("Spc.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Specular'])
                            
                if img_path.endswith("Rgh.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Roughness'])
                            
                if img_path.endswith("Emm.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Emission Color'])
                                
                if img_path.endswith("Opa.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Alpha'])
                    
                if img_path.endswith("Alp.png"):
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(img_node.outputs[0], bsdf.inputs['Alpha'])
            
                if img_path.endswith("Nrm.png"):
                    nrm_node = nodes.new("ShaderNodeNormalMap")
                    img_node.image.colorspace_settings.name = 'Non-Color'
                    links.new(nrm_node.outputs[0], bsdf.inputs['Normal'])
                    links.new(img_node.outputs[0], nrm_node.inputs[1])
                   
        # Ink Driver 
        if True:
            if ink_noise == None:
                ink_noise = nodes.new(type="ShaderNodeTexNoise")
                ink_noise.inputs['Scale'].default_value = 3.3
                ink_noise.inputs['Detail'].default_value = 1
                ink_noise.inputs['Roughness'].default_value = 0.45


            # -- INK A
            # Mix Shader
            shader_mix = nodes.new(type="ShaderNodeMixShader")
            links.new(bsdf.outputs[0], shader_mix.inputs[1])
            links.new(shader_mix.outputs[0], output.inputs[0])
            shader_mix.location = Vector((1000, 0))
            
            # Math Subtract
            sub = nodes.new(type="ShaderNodeMath")
            sub.operation = 'SUBTRACT'
            sub.location = Vector((400, -300))
            
            # DRIVER
            driver = sub.inputs[0].driver_add('default_value').driver
            v = driver.variables.new()
            v.name = 'InkA'
            v.targets[0].id = armature
            v.targets[0].bone_target = "Ink_A"
            v.type = 'TRANSFORMS'
            v.targets[0].transform_space = 'LOCAL_SPACE'
            v.targets[0].transform_type = 'LOC_Y'
            driver.expression = v.name
            
            # Math Add
            add = nodes.new(type="ShaderNodeMath")
            links.new(sub.outputs[0], add.inputs[0])
            if ink_noise != None:
                ink_noise.location = Vector((300, -500))
                links.new(ink_noise.outputs[0], add.inputs[1])
            add.location = Vector((570, -300))
            
            # Math Round
            round = nodes.new(type="ShaderNodeMath")
            round.operation = 'ROUND'
            
            links.new(add.outputs[0], round.inputs[0])
            links.new(round.outputs[0], shader_mix.inputs[0])
            
            round.location = Vector((735, -300))
            
            # Ink BSDF
            ink_bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
            ink_bsdf.location = Vector((625, -500))
            
            ink_bsdf.inputs[0].default_value = (self.ink_A.r, self.ink_A.g, self.ink_A.b, 1)
            ink_bsdf.inputs['Roughness'].default_value = 0.3
            ink_bsdf.inputs['Specular IOR Level'].default_value = 0.7
            ink_bsdf.inputs['Anisotropic'].default_value = 0.3
            
            links.new(ink_bsdf.outputs[0], shader_mix.inputs[2])
            
            # -- INK B
            x = 1000
            # Mix Shader
            shader_mix2 = nodes.new(type="ShaderNodeMixShader")
            links.new(shader_mix.outputs[0], shader_mix2.inputs[1])
            links.new(shader_mix2.outputs[0], output.inputs[0])
            shader_mix2.location = Vector((x+1000, 0))
            
            # Math Subtract
            sub = nodes.new(type="ShaderNodeMath")
            sub.operation = 'SUBTRACT'
            sub.location = Vector((x+400, -300))
            
            # DRIVER
            driver = sub.inputs[0].driver_add('default_value').driver
            v = driver.variables.new()
            v.name = 'InkB'
            v.targets[0].id = armature
            v.targets[0].bone_target = "Ink_B"
            v.type = 'TRANSFORMS'
            v.targets[0].transform_space = 'LOCAL_SPACE'
            v.targets[0].transform_type = 'LOC_Y'
            driver.expression = v.name
            
            # Math Add
            add = nodes.new(type="ShaderNodeMath")
            links.new(sub.outputs[0], add.inputs[0])
            if ink_noise != None:
                ink_noise.location = Vector((300, -500))
                links.new(ink_noise.outputs[0], add.inputs[1])
            add.location = Vector((x+570, -300))
            
            # Math Round
            round = nodes.new(type="ShaderNodeMath")
            round.operation = 'ROUND'
            
            links.new(add.outputs[0], round.inputs[0])
            links.new(round.outputs[0], shader_mix2.inputs[0])
            
            round.location = Vector((x+735, -300))
            
            # Ink BSDF
            ink_bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
            ink_bsdf.location = Vector((x+625, -500))
            
            ink_bsdf.inputs[0].default_value = (self.ink_B.r, self.ink_B.g, self.ink_B.b, 1)
            ink_bsdf.inputs['Roughness'].default_value = 0.3
            ink_bsdf.inputs['Specular IOR Level'].default_value = 0.7
            ink_bsdf.inputs['Anisotropic'].default_value = 0.3
            
            links.new(ink_bsdf.outputs[0], shader_mix2.inputs[2])
        
        self.report({'INFO'}, str(self.affected_by_transparency))
        self.report({'INFO'}, str(armature))
        if self.affected_by_transparency and armature != None:
            transparencify(bpy.context.active_object.active_material, armature)


            
        
        if self.cloth_type == "shs":
            # the new object is created with the old object's data, which makes it "linked"
            new_child = bpy.data.objects.new(child.name+"_R", child.data)
            
            bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False, obdata_animation=False)
            
            child.name = child.name+"_L"
            bpy.context.collection.objects.link(new_child)
            new_child.scale = child.scale
            new_child.location = child.location
            new_child.rotation_euler = child.rotation_euler
            
            new_child.scale = (-1 * new_child.scale.x, 1 * new_child.scale.y, 1 * new_child.scale.z)
            
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.normals_make_consistent(inside=False)
            bpy.ops.object.editmode_toggle()
            
            if use_armature:
                new_child.location[0] = -0.097*armature.scale.x + armature.location.x
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.remove_doubles(threshold=0.001, use_unselected=True, use_sharp_edge_from_normals=True)
            bpy.ops.object.editmode_toggle()
            
            name_list2 = [
                ['Leg_2_L', 'Leg_2_R'],
                ['Ankle_L', 'Ankle_R'],
                ['Toe_L', 'Toe_R'],
                ['Ankle_Assist_L', 'Ankle_Assist_R']
            ]

            v_groups2 = new_child.vertex_groups
            for n in name_list2:
                if n[0] in v_groups2:
                    if v_groups2[n[0]] != None:
                        v_groups2[n[0]].name = n[1]
            
            if use_armature:
                bpy.ops.object.select_all(action='DESELECT')
                new_child.select_set(True)
                armature.select_set(True)
                bpy.context.view_layer.objects.active = armature
                bpy.ops.object.parent_set(type='ARMATURE')

    
    if use_armature:
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.delete(use_global=False)
    
        bpy.ops.object.select_all(action='DESELECT')
        armature.select_set(True)
        bpy.context.view_layer.objects.active = armature
    else:
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
    
    return {'FINISHED'}

def clean(obj):
    bpy.ops.object.mode_set(mode = 'EDIT') 
    mesh = obj.data
    connected_verts = []
    for edge in mesh.edges:
        connected_verts.append(edge.vertices[0])
        connected_verts.append(edge.vertices[1])
    connected_vert = set(connected_verts)
    unconnected_vert = set(range(len(mesh.vertices))) - connected_vert
    bpy.ops.mesh.select_all(action='DESELECT')
    for vert in connected_verts:
        print(mesh.vertices[vert])
        bpy.ops.object.mode_set(mode='OBJECT')
        mesh.vertices[vert].select = True
    bpy.ops.object.editmode_toggle()
    bpy.ops.mesh.select_all(action='INVERT')
    bpy.ops.mesh.delete(type='VERT')

from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty, FloatVectorProperty, FloatProperty
from bpy.types import Operator

class import_cloth(Operator, ImportHelper):
    bl_idname = "import_splatoon_3.cloth"
    bl_label = "Import Splatoon 3 Cloth"


    filter_glob: StringProperty(
        default="*.dae",
        options={'HIDDEN'},
        maxlen=255,
    )
    
    name: StringProperty(
        name="Name",
        description="The name you want to give to the cloth"
    )
    
    ink_A: FloatVectorProperty(
        name="Team Color",
        description="The ink color of the imported cloth",
        default=(1, 0, 0),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    
    ink_B: FloatVectorProperty(
        name="Opponent Team Color",
        description="The opponent ink color for the ink splash",
        default=(0, 1, 1),
        min=0.0, max=1.0,
        subtype='COLOR'
    )
    
    cloth_type: EnumProperty(
        name="Cloth Type",
        description="The type of the imported cloth.",
        items=(
            ('head', 'Head Accessory', 'Hat, Mask, Glasses, Earring, etc'),
            ('clt', 'Body Cloth', 'T-shirt, Jacket, Parka, Sweater, Vest, etc'),
            ('shs', 'Shooes', 'Boots, Baskets, Sandals, etc')
        )
    )
    
    mask_type: EnumProperty(
        name="Alpha Mask (Cloth)",
        description="Choose the mask to hide the skin behind the clothes",
        items=(
            ('none', "Nothing", "No Mask"),
            ('clt_00_big_opa.png', "Body and Shoulders", "Mask 00 big"),
            ('clt_00_wide_opa.png', "Body and 1/4 Arms", "Mask 00 wide"),
            ('clt_01_opa.png', "Body and 1/2 Arms", "Mask 01"),
            ('clt_02_opa.png', "Body and Arms", "Mask 02"),
            ('clt_03_opa.png', 'Belly', "Mask 03"),
            ('clt_04_opa.png', 'Body, Shoulders and 1/2 Fingers', "Mask 04"),
            ('clt_05_opa.png', 'Body and Arms without Shoulders', "Mask 05"),
            ('clt_06_opa.png', 'Body and Arms without Shoulders', "Mask 06"),
            ('clt_07_opa.png', 'Body, Arms and 1/2 Fingers', "Mask 07"),
            ('clt_08_opa.png', 'Torso, Wrists and 1/2 Fingers', "Mask 08"),
            ('clt_09_opa.png', 'Body, Arms and Hands', "Mask 09"),
            ('clt_10_opa.png', 'Body, 1/2 Arms without Neck', "Mask 10"),
            ('clt_11_opa.png', 'Body, 1/2 Arms without Bowl', "Mask 11"),
            ('clt_12_opa.png', 'Belly, Torso and Hands', "Mask 12"),
            ('clt_13_opa.png', 'Belly and Torso', "Mask 13"),
            ('clt_14_opa.png', 'Body, Arms and 1/2 Fingers', "Mask 14"),
            ('clt_15_opa.png', 'Neck and Torso', "Mask 15"),
            ('clt_16_opa.png', 'Neck, Torso and 1/2 Belly', "Mask 16"),
            ('clt_17_opa.png', 'Body, Neck and 1/2 Arms', "Mask 17"),
            ('clt_18_opa.png', 'Body, Neck and Arms', "Mask 18"),
            ('clt_19_opa.png', 'Asymmetric', "Mask 19"),
            ('clt_20_opa.png', 'Entire Body without Neck and Head', "Mask 20"),
            ('clt_21_opa.png', 'Body, 1/2 Arms without Neck and Torso', "Mask 21"),
            ('clt_22_opa.png', 'Right Wrists and 1/2 Fingers', "Mask 22"),
            ('clt_23_opa.png', 'All Neck, Body and Arms', "Mask 23"),
            ('clt_24_opa.png', 'Body, Shoulders without Chest', "Mask 24"),
            ('clt_25_opa.png', 'Body without Arms', "Mask 25"),
            ('clt_26_opa.png', 'Body, 3/4 Arms and 1/2 Fingers', "Mask 26"),
            ('clt_27_opa.png', 'Body, 3/4 Arms without belly', "Mask 27"),
            ('clt_28_opa.png', 'Torso, Neck, 1/2 Arms and Wrists', "Mask 28"),
            ('clt_29_opa.png', 'Body, 3/4 Arms whithout Neck', "Mask 29"),
            ('clt_30_opa.png', 'Body, Shoulders whithout Neck', "Mask 30"),
            ('clt_31_opa.png', 'Body, Shoulders whithout Neck and without 1/2 Torso', "Mask 31"),
            ('clt_32_opa.png', 'Body, Right Wrist', "Mask 32"),
            ('clt_33_opa.png', 'Torso and Righth 1/2 Arm', "Mask 33")
        ),
        default='none',
    )
    mask_type_shs: EnumProperty(
        name="Alpha Mask (Shooes)",
        description="Choose the mask to hide the skin behind the shooes",
        items=(
            ('none', "Nothing", "No Mask"),
            ('shs_00_opa.png', "Toe and Bottom", "Mask 00"),
            ('shs_01_opa.png', "Toe, 1/2 Foot and Bottom", "Mask 01"),
            ('shs_02_opa.png', "Foot", "Mask 02"),
            ('shs_03_opa.png', "Foot and Ankle", "Mask 03"),
            ('shs_04_opa.png', "Foot, Ankle and 1/2 Leg", "Mask 04"),
            ('shs_05_opa.png', "Foot, Ankle and 1/4 Leg", "Mask 05"),
            ('shs_06_opa.png', "1/3 Foot", "Mask 06")
        ),
        default='none',
    )
    shooe_height: EnumProperty(
        name="Shooe Height",
        description="How high does the shoe reach",
        items=(
            ('knee', "Knee", ""),
            ('ankle', "Ankle", ""),
        ),
        default='knee',
    )
    affected_by_transparency: BoolProperty(
        name="Affected by Transparency",
        description='Do the cloth become transparent when character transparency bone is moved?',
        default=True
    )

    hue: FloatProperty(
        name="Hue",
        description="The hue decal of the main texture",
        default=0.5,
        min=0.0, max=1.0
    )
    
    clean: BoolProperty(
        name="Clean Vertices",
        description='Remove all unused vertices',
        default=True
    )

    def execute(self, context):
        return import_clt(self)


def menu_func_import(self, context):
    self.layout.operator(import_cloth.bl_idname, text="Splatoon 3 Cloth")

def register():
    bpy.utils.register_class(import_cloth)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
def unregister():
    bpy.utils.unregister_class(import_cloth)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()
