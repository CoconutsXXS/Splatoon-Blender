bl_info = {
    "name": "Dynamic Ink",
    "author": "Coconuts XXS",
    "version": (0, 1),
    "blender": (4, 0, 2),
    "location": "View3D > Add > Mesh > Ink Emitter",
    "description": "Create dynamic ink which can paint on any surface",
    "warning": "",
    "doc_url": "",
    "category": "Add Mesh",
}

import bpy
import pprint
from mathutils import Vector
from bpy_extras.object_utils import AddObjectHelper, object_data_add
import math
import time
import os
import re

#   --  MENUE   --
# Button
class Ink_Surface(bpy.types.Operator):
    bl_idname = "view3d.ink_surface"
    bl_label = "Dynamic Ink Surface"
    bl_option = {
        'REGISTER',
        'UNDO',
    }
    bl_description = "Allows ink to paint the surface"

    def execute(self, context):
        if bpy.context.object == None:
            self.report({"ERROR"}, 'Please select a mesh')
            return {'FINISHED'}
        if bpy.context.object.type != "MESH":
            self.report({"ERROR"}, 'Please select a mesh')
            return {'FINISHED'}
        for modifier in bpy.context.object.modifiers:
            if modifier.type == "DYNAMIC_PAINT":
                self.report({"ERROR"}, 'The mesh already use dynamic painting')
                return {'FINISHED'}

        
        bpy.ops.object.dialog_operator('INVOKE_DEFAULT')
        
        return {'FINISHED'}
class Ink_Surface_Bake(bpy.types.Operator):
    bl_idname = "view3d.ink_surface_bake"
    bl_label = "Bake Ink Surface"
    bl_option = {
        'REGISTER',
        'UNDO',
    }
    bl_description = "Generate the ink animation"

    def execute(self, context):
        if len(bpy.context.selected_objects) == 0:
            self.report({'ERROR'}, 'Please, select one mesh')
            return {'FINISHED'}
        
        i = 0
        for obj in bpy.context.selected_objects:
            i += 1
            if obj.type != "MESH":
                self.report({"ERROR"}, 'Please, select mesh')
                continue
            
            has_dyna_paint = False
            for modifier in obj.modifiers:
                if modifier.type == "DYNAMIC_PAINT":
                    if modifier.ui_type == 'CANVAS':
                        has_dyna_paint = True
            if not has_dyna_paint:
                self.report({"ERROR"}, 'Please set the surface as dynamic ink surface')
                continue
            
            self.report({'INFO'}, str(bpy.context.selected_objects[i:]))
            bake(obj, self, context, bpy.context.selected_objects[i:])
            break
        
        return {'FINISHED'}

class Ink_Surface_Bake_Apply(bpy.types.Operator):
    bl_idname = "view3d.ink_surface_bake_apply"
    bl_label = "Apply Baked Ink"
    bl_option = {
        'REGISTER',
        'UNDO',
    }
    bl_description = "Finalize the ink animation"

    def execute(self, context):
        if len(bpy.context.selected_objects) == 0:
            self.report({'ERROR'}, 'Please, select one or more mesh')
            return {'FINISHED'}
        
        for obj in bpy.context.selected_objects:
            if obj.type != "MESH":
                self.report({"ERROR"}, 'Please, select mesh')
                continue
            
            has_dyna_paint = False
            for modifier in obj.modifiers:
                if modifier.type == "DYNAMIC_PAINT":
                    has_dyna_paint = True
            if not has_dyna_paint:
                self.report({"ERROR"}, 'Please set the surface as dynamic ink surface')
                continue
            
            apply_bake(obj, self )
        
        return {'FINISHED'}
    
class Ink_Surface(bpy.types.Operator):
    bl_idname = "view3d.ink_surface"
    bl_label = "Dynamic Ink Surface"
    bl_option = {
        'REGISTER',
        'UNDO',
    }
    bl_description = "Allows ink to paint the surface"

    def execute(self, context):
        bpy.ops.object.dialog_operator('INVOKE_DEFAULT')
        
        return {'FINISHED'}
class Ink_Emmiter(bpy.types.Operator):
    bl_idname = "view3d.ink_emmiter"
    bl_label = "Ink Emmiter"
    bl_option = {
        'REGISTER',
        'UNDO',
    }
    bl_description = "Set the object to an ink emitter"

    def execute(self, context):
        bpy.ops.object.emmiter_dialog_operator('INVOKE_DEFAULT')
        
        return {'FINISHED'}
    
    
# ADD MESH
class OBJECT_OT_add_ink(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.ink"
    bl_label = "Add Ink Emitter"
    bl_description = "Add a customizable ink emitter"
    bl_options = {'REGISTER', 'UNDO'}
    
    name: bpy.props.StringProperty(
        name="Name",
        description="The name of the object",
        maxlen=50,
        default="Splatter",
    )
    type: bpy.props.EnumProperty(
        name='Effect',
        items=(
            ('Particles', 'Continuous Firing', ''),
            ('Explosion', 'Splash Explosion', '')
        )
    )
    ink: bpy.props.FloatVectorProperty(  
       name="Color",
       subtype='COLOR',
       default=(1, 0, 0),
       min=0.0, max=1.0,
       description="The ink color"
    )
    speed: bpy.props.FloatProperty(  
       name="Speed",
       default=10,
       min=0.0,
       description="The speed of the particles"
    )
    angle: bpy.props.FloatProperty(  
       name="Angle",
       default=10,
       min=1.0, max=90,
       description="More it's hight more ink is projected in multiple directions"
    )
    size: bpy.props.FloatProperty(  
       name="Size",
       default=1,
       min=0,
       description="The scale of the particles"
    )
    volume: bpy.props.FloatProperty(  
       name="Volume",
       default=70 ,
       min=0,
       description="The volume of the ink, more it's hight more particles connect together"
    )
    stiffness: bpy.props.FloatProperty(  
       name="Stiffness",
       default=1 ,
       min=0,
       description="The ink particles stffness"
    )

    def execute(self, context):
        addInk(self, context)
        return {'FINISHED'}

# Registration
def add_ink_button(self, context):
    self.layout.operator(
        OBJECT_OT_add_ink.bl_idname,
        text="Ink Emitter",
        icon='PARTICLES')
    
# Menue
class DialogOperator(bpy.types.Operator):
    bl_idname = "object.dialog_operator"
    bl_label = "Ink Surface"

    # color: bpy.props.FloatVectorProperty(name="Ink Color", subtype="COLOR", default=(1, 0, 0))
    displacement: bpy.props.BoolProperty(name="Displacement (Cycles)", description="Modify the mesh to add relief, require many vertices and works only in Cycles", default=False)
    
    resolution: bpy.props.IntProperty(name="Resolution", default=1080)
    sub_steps: bpy.props.IntProperty(name="Painting Quality", description="Subs-Steps", default=10)
    
    drip: bpy.props.BoolProperty(name="Drip", default=True)
    impermeability: bpy.props.BoolProperty(name="Impermeability", default=False)
    pierceable: bpy.props.BoolProperty(name="Pierceable", default=False)
    
    waves: bpy.props.BoolProperty(name="Waves", default=False)
    
    def execute(self, context):
        objs = list()
        if len(bpy.context.selected_objects) == 0:
            self.report({'ERROR'}, 'Please, select one or more object')
            return {'FINISHED'}
        
        for obj in  bpy.context.selected_objects:
            if obj.type == 'MESH':
                objs.append(obj)
                surface(obj, self, context)
        for obj in  objs:
            obj.select_set(True)
        
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class EmmiterDialogOperator(bpy.types.Operator):
    bl_idname = "object.emmiter_dialog_operator"
    bl_label = "Ink Emmiter"

    color: bpy.props.FloatVectorProperty(name="Ink Color", subtype="COLOR", default=(1, 0, 0))
    surface: bpy.props.EnumProperty(
        name="Surface",
        description="Where the ink is emitted",
        items=(
            ('VOLUME', 'Surface', 'Rollers, brushes, etc'),
            ('PARTICLE_SYSTEM', 'Particles', 'Shooters, bombes, etc')
        )
    )
    intensity: bpy.props.FloatProperty(name="Intensity", default=1.0)
    scale: bpy.props.FloatProperty(name="Particle Size", default=0.5)
    
    waves: bpy.props.BoolProperty(name="Waves", default=False)
    waves_intensity: bpy.props.FloatProperty(name="Waves Intensity", default=0.3)

    def execute(self, context):
        set_emmiter(bpy.context.object, self, context)
        
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
def menu_func(self, context):
    self.layout.operator(Ink_Emmiter.bl_idname)
    self.layout.operator(Ink_Surface.bl_idname)
    self.layout.operator(Ink_Surface_Bake.bl_idname)
    #self.layout.operator(Ink_Surface_Bake_Apply.bl_idname)
    #self.layout.operator(DialogOperator.bl_idname, text="Ink Surface")
    #self.layout.operator(EmmiterDialogOperator.bl_idname, text="Ink Emmiter")

def register():
    bpy.utils.register_class(DialogOperator)
    bpy.utils.register_class(EmmiterDialogOperator)
    
    bpy.utils.register_class(Ink_Emmiter)
    bpy.utils.register_class(Ink_Surface)
    bpy.utils.register_class(Ink_Surface_Bake)
    #bpy.utils.register_class(Ink_Surface_Bake_Apply)
    
    bpy.types.VIEW3D_MT_object_context_menu.append(menu_func)
    
    bpy.utils.register_class(OBJECT_OT_add_ink)
    bpy.types.VIEW3D_MT_mesh_add.append(add_ink_button)
        

def unregister():
    bpy.utils.unregister_class(DialogOperator)
    bpy.utils.unregister_class(EmmiterDialogOperator)
    
    bpy.utils.unregister_class(Ink_Emmiter)
    bpy.utils.unregister_class(Ink_Surface)
    bpy.utils.unregister_class(Ink_Surface_Bake)
    #bpy.utils.unregister_class(Ink_Surface_Bake_Apply)

    bpy.types.VIEW3D_MT_object_context_menu.remove(menu_func)
    
    bpy.utils.unregister_class(OBJECT_OT_add_ink)
    bpy.types.VIEW3D_MT_mesh_add.remove(add_ink_button)

if __name__ == "__main__":
    register()



#   --  ADDON   --
from bpy.utils import resource_path
from pathlib import Path

# Path
USER = Path(resource_path('USER'))
ADDON = "Dynamic Ink"
srcPath = USER / "scripts" / "addons" / ADDON

def path_iterator(folder_path):
    for fp in os.listdir(folder_path):
        if fp.endswith( tuple( bpy.path.extensions_image ) ):
            yield fp
        

# -- SURFACE --
# Canvas
def surface(obj, self, context):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    
    # UV
    bpy.ops.object.editmode_toggle()
    UV = bpy.ops.mesh.uv_texture_add()
    bpy.context.object.data.uv_layers.active.name = "Ink Surface"
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(scale_to_bounds=True)
    bpy.ops.object.editmode_toggle()
    
    # Canvas
    bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')
    bpy.ops.dpaint.type_toggle(type='CANVAS')
    
    # Waves
    if self.waves:
        bpy.ops.dpaint.surface_slot_add()
        wave = obj.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces[0]
        wave.name = "Waves"
        wave.surface_format = 'VERTEX'
        wave.surface_type = 'WAVE'
        wave.use_wave_open_border = True
        wave.brush_radius_scale = 0.15
        wave.wave_smoothness = 0.07
        wave.wave_spring = 0
        wave.wave_damping = 0.7
    
        surface = obj.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces["Surface.001"]
    if obj.modifiers["Dynamic Paint"].canvas_settings == None:
        return
    else:
        surface = obj.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces["Surface"]
    surface.name = "Surface"
    # resolution
    surface.surface_format = 'IMAGE'
    surface.image_resolution = self.resolution
    surface.frame_substeps = self.sub_steps
    # no dry
    surface.use_drying = False
    # drip
    surface.use_drip = self.drip
    surface.drip_velocity = 0.7
    surface.drip_acceleration = 0.6
    surface.effector_weights.gravity = 0.07
    surface.effector_weights.all = 0.1
    # cache
    texture_name = namify(obj.name)
    surface.image_output_path = "//dynamic_ink"
    surface.output_name_a = texture_name
    # uv
    surface.uv_layer = bpy.context.object.data.uv_layers.active.name

    # Collision
    bpy.ops.object.modifier_add(type='COLLISION')
    bpy.context.object.collision.use_particle_kill = True
    
    # Shader
    path=str(srcPath) + "/shader.blend"
    shader_group = None
    base_shader_group = None
    group_name = "Paint Surface"
    base_group_name = "External Paint Surface"
        
    shearched = None
    with bpy.data.libraries.load(path, link=False) as (data_from, data_to):
        print(self, 'Groups Importation : '+str(data_from.node_groups))
        data_to.node_groups = [group_name, base_group_name]
        #if group_name in data_from.node_groups:
        #    data_to.node_groups = [group_name]
        #    shearched = data_to.node_groups[0]
        #if base_group_name in data_from.node_groups:
        #    data_to.node_groups = [base_group_name]
                
    self.report({"INFO"}, str(bpy.data.node_groups))
    self.report({"INFO"}, str(shearched))
    
    # if shearched in bpy.data.node_groups:
    for grp in bpy.data.node_groups:
        print(self, 'Groups Here : '+grp.name)
        if grp.name == "Paint Surface":
            shader_group = grp
            shader_group.name = namify(obj.name)
        if grp.name == "External Paint Surface":
            base_shader_group = grp
            base_shader_group.name = "External Paint Surface - " + obj.name
    
    # Modify Material
    for slot in obj.material_slots:
        material = slot.material
        tree = material.node_tree
        
        if self.displacement:
            material.cycles.displacement_method = 'DISPLACEMENT'
        else:
            material.cycles.displacement_method = 'BUMP'
        
        # group
        group_node = tree.nodes.new("ShaderNodeGroup")
        group_node.node_tree = shader_group
        group_node.location = Vector((300, 0))
        
        base_group_node = tree.nodes.new("ShaderNodeGroup")
        base_group_node.node_tree = base_shader_group
        base_group_node.location = Vector((300, -300))
        
        # setup
        nodes = tree.nodes
        links = tree.links
        
        # find original shader
        original = None
        old_output = None
        for node in nodes:
            if node.type == "OUTPUT_MATERIAL":
                original = node.inputs['Surface'].links[0].from_node
                old_output = node
                break
        
        # add new outputs
        eevee_output = nodes.new(type="ShaderNodeOutputMaterial")
        eevee_output.target = 'EEVEE'
        eevee_output.location = Vector((600, 100))
        cycles_output = nodes.new(type="ShaderNodeOutputMaterial")
        cycles_output.target = 'CYCLES'
        cycles_output.location = Vector((600, -100))
        
        self.report({"INFO"}, str(group_node))
        self.report({"INFO"}, str(shader_group))
        
        # link outputs
        tree.links.new(group_node.outputs['EEVEE'], eevee_output.inputs['Surface'])
        tree.links.new(group_node.outputs['Cycles'], cycles_output.inputs['Surface'])
        tree.links.new(group_node.outputs['Displacement'], cycles_output.inputs['Displacement'])
        
        # link inputs
        if original != None:
            tree.links.new(original.outputs[0], group_node.inputs['Shader'])
        
        # delete old output
        if old_output != None:
            nodes.remove(old_output)
        
        # uv
        uv_node = nodes.new(type="ShaderNodeUVMap")
        uv_node.uv_map = bpy.context.object.data.uv_layers.active.name
        uv_node.location = Vector((130, -230))
        tree.links.new(uv_node.outputs[0], group_node.inputs['UV'])
                        
    return {'FINISHED'}

import functools

def after_bake(next):
    if len(next) > 0:
        i = 0
        for obj in next:
            i += 1
            if obj.type != "MESH":
                self.report({"ERROR"}, 'Please, select mesh')
                continue
            
            has_dyna_paint = False
            for modifier in obj.modifiers:
                if modifier.type == "DYNAMIC_PAINT":
                    has_dyna_paint = True
            if not has_dyna_paint:
                self.report({"ERROR"}, 'Please set the surface as dynamic ink surface')
                continue
            
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            
            bake(obj, None, None, next[i:])
            break
def bake(obj, self, context, next):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    
    if not bpy.data.is_saved and self != None:
        self.report({'ERROR'}, 'Please save the file before baking')
        return {'FINISHED'}
    
    base_path = str(bpy.path.abspath("//dynamic_ink"))
    # Remove
    if os.path.exists(base_path):
        for image_name in get_image_file("//dynamic_ink/", namify(obj.name)):
            os.remove( os.path.join(base_path, image_name) )
        
    # Duration
    duration = -1
    for surface in obj.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces:
        if surface.surface_type == 'PAINT' and surface.surface_format == 'IMAGE':
            duration = surface.frame_end - surface.frame_start
            
    if duration == -1 and self != None:
        self.report({'ERROR'}, 'Object is not a dynamic ink surface.')
        after_bake(next)
        return {'FINISHED'}
        

    # bake
    bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
    bpy.ops.dpaint.bake()
    
    if self != None:
        self.report({'INFO'}, 'Baking ink Surface, this operation can take time.')
    
    
    def in_5_seconds():
        if len(get_image_file(base_path, namify(obj.name))) >= duration:
            apply_bake(obj)
            #bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            #bpy.context.active_object.name = str(next)
            after_bake(next)
            return None
        return 1
    
    bpy.app.timers.register(in_5_seconds)
    
    return {'FINISHED'}


from bpy.types import OperatorFileListElement
def apply_bake(obj, self = None):
    for slot in obj.material_slots:
        material = slot.material
        tree = material.node_tree
        
        # group
        group_node = None
        base_group_node = None
        groups = [node for node in tree.nodes if node.type == 'GROUP']
        for group in groups:
            if group.node_tree.name == namify(obj.name):
                group_node = group
            if group.node_tree.name == "External Paint Surface - " + obj.name:
                base_group_node = group
        
        if group_node == None and self != None:
            self.report({"ERROR"}, 'Ink surface group node not found...')
            return {'FINISHED'}
        
        # setup
        nodes = tree.nodes
        links = tree.links
        
        # Sequence Creation
        #path = bpy.path.abspath("//dynamic_ink/")
        path ="//dynamic_ink/"
        file_name_list = get_image_file(path, namify(obj.name))
        file_info = list()
        for image_name in file_name_list:
            file_info.append({"name": image_name})
        
        bpy.ops.image.open(directory=path, files=file_info, show_multiview=False)
        
        image_data_name = file_name_list[0]
        image_sequence = bpy.data.images[image_data_name]
        duration = len(file_name_list)
        
        # image sequence
        for node in group_node.node_tree.nodes:
            if node.type == "TEX_IMAGE":
                node.image = image_sequence
                node.image.source = 'SEQUENCE'
                node.image_user.frame_duration = duration
                node.image_user.use_auto_refresh = True
                node.image_user.frame_offset = 0
                
        for node in base_group_node.node_tree.nodes:
            if node.type == "TEX_IMAGE":
                node.image = image_sequence
                node.image.source = 'SEQUENCE'
                node.image_user.frame_duration = duration
                node.image_user.use_auto_refresh = True
                node.image_user.frame_offset = 0


        return {'FINISHED'}
    
def get_image_file(path, name):
    image_file = list()
    
    for file_name in os.listdir(bpy.path.abspath(path)):
        if file_name.startswith(name):
            image_file.append(file_name)
            
    image_file.sort()
    pprint.pprint(image_file)
    return image_file
def namify(name):
    return "Paint Surface - " + name + ': '

def print(self, message):
    self.report({"INFO"}, str(message))

# -- EMMITER --
def set_emmiter(obj, self, context):
    if bpy.context.object.type != "MESH" and self.surface == "VOLUME":
        self.report({"WARNING"}, 'Surface ink can only be set on mesh')
    
    for modifier in bpy.context.object.modifiers:
        if modifier.type == "DYNAMIC_PAINT":
            self.report({"ERROR"}, 'The mesh already use dynamic painting')
            return {'FINISHED'}
    
    bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')
    
    modifier = None
    for m in bpy.context.object.modifiers:
        if m.type == "DYNAMIC_PAINT":
            modifier = m
    
    modifier.ui_type = 'BRUSH'
    bpy.ops.dpaint.type_toggle(type='BRUSH')
    
    modifier.brush_settings.paint_color = self.color
    bpy.context.object.modifiers["Dynamic Paint"].brush_settings.paint_alpha = self.intensity*0.3
    modifier.brush_settings.paint_source = self.surface
    
    if self.surface == 'PARTICLE_SYSTEM':
        if len(bpy.data.objects["Splatter"].particle_systems) == 0:
            self.report({'ERROR'}, 'Your object does not have any particle system...')
            return {'ERRORED'}
        modifier.brush_settings.particle_system = bpy.context.object.particle_systems[0]
        modifier.brush_settings.solid_radius = self.scale
        modifier.brush_settings.smooth_radius = 0.4

    modifier.brush_settings.use_velocity_depth = True
    
    # Waves
    if self.waves:
        bpy.context.object.modifiers["Dynamic Paint"].brush_settings.wave_factor = self.waves_intensity
    else:
        bpy.context.object.modifiers["Dynamic Paint"].brush_settings.wave_factor = 0

        

    
        

def create_emmiter():
    bpy.ops.object.particle_system_add()
    bpy.data.particles["Inker"].name = "Inker"
    bpy.data.particles["Inker"].render_type = 'OBJECT'
    bpy.data.particles["Inker"].instance_object = bpy.data.objects["Ink A"]
    bpy.data.particles["Inker"].particle_size = 0.2
    bpy.data.particles["Inker"].size_random = 0.5
    bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')
    bpy.context.object.modifiers["Dynamic Paint"].ui_type = 'BRUSH'
    bpy.ops.dpaint.type_toggle(type='BRUSH')
    bpy.context.object.modifiers["Dynamic Paint"].brush_settings.paint_source = 'PARTICLE_SYSTEM'
    bpy.context.object.modifiers["Dynamic Paint"].brush_settings.particle_system = bpy.data.objects["Plane.001"].particle_systems["ParticleSystem"]
    bpy.context.object.modifiers["Dynamic Paint"].brush_settings.paint_color = (1, 1, 1)
    bpy.context.object.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces["Surface"].output_name_a = "BLABLABLA" # Change

    # Particle
    bpy.ops.outliner.collection_new(nested=True)
    bpy.ops.object.metaball_add(type='BALL', enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
    bpy.ops.object.editmode_toggle()
    bpy.ops.transform.resize(value=(0.35, 0.35, 0.35))
    bpy.ops.object.editmode_toggle()
    bpy.context.object.data.resolution = 0.1
    bpy.context.object.data.render_resolution = 0.05
    # bpy.data.scenes["Scene"].(null) = True
    
    
def addInk(self, context):
    path=str(srcPath) + "/"+self.type+".blend"
    print(self, path)
    with bpy.data.libraries.load(path, link=False) as (data_from, data_to):
        data_to.objects = data_from.objects
    for o in data_to.objects:
        bpy.context.collection.objects.link(o)
        
        print(self, self.ink[1])
        
        if o.type == 'META':
            o.name = str( to_hex(self.ink[0], self.ink[1], self.ink[2]) )
            o.data.name = str( to_hex(self.ink[0], self.ink[1], self.ink[2]) )
            o.active_material.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (self.ink[0], self.ink[1], self.ink[2], 1)
            
            o.data.elements[0].radius = self.volume
            o.data.elements[0].stiffness = (0.25/70)*self.volume*self.stiffness
            
            o.select_set(False)
        elif o.type == 'MESH':
            if o.data.shape_keys != None:
                o.data.shape_keys.key_blocks[1].value = -(self.angle/90)+1
            o.location = self.location
            o.rotation_euler = self.rotation
            
            o.modifiers['ParticleSystem'].particle_system.settings.normal_factor = self.speed
            o.modifiers['ParticleSystem'].particle_system.settings.particle_size = self.size*0.07
            
            o.name = self.name
             
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = o
            o.select_set(True)
            
def to_hex(r,g,b):
    rgb = [r,g,b]
    result = ""
    i=0
    while i < 3:
        val = str(c_to_hex(rgb[i]))
        val = val[2:]
        if len(val) == 1:
            val += val
        result+=val
        i+=1
    return result

def c_to_hex(c):
    if c < 0.0031308:
        srgb = 0.0 if c < 0.0 else c * 12.92
    else:
        srgb = 1.055 * math.pow(c, 1.0 / 2.4) - 0.055

    return hex(max(min(int(srgb * 255 + 0.5), 255), 0))